# GobernArg — Grupo G completo

Incluye 14 personajes y asesores para el juego.

Estructura:
- `src/assets/images/advisors/` → asesores
- `src/assets/images/characters/` → personajes
- `src/assets/images/raw/` → PNG fuente
- `src/assets/images/INVENTORY.md` → inventario

Nota honesta:
G1 a G10 fueron generados como retratos individuales. G11 a G14 fueron recuperados como recortes de una lámina generada porque la herramienta insistió en producir previews en vez de retratos separados. Sirven como versión provisoria para integrar y testear el juego, pero conviene regenerarlos individualmente más adelante si se busca calidad final perfecta.