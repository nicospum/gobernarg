# INVENTORY

Grupo G completo (14 personajes y asesores).

| Archivo | Tipo | Raw PNG | WebP |
|---|---|---|---|
| advisor-infrastructure-male.webp | generated | src/assets/images/raw/advisor-infrastructure-male.png | src/assets/images/advisors/advisor-infrastructure-male.webp |
| advisor-foreign-male.webp | generated | src/assets/images/raw/advisor-foreign-male.png | src/assets/images/advisors/advisor-foreign-male.webp |
| advisor-education-male.webp | generated | src/assets/images/raw/advisor-education-male.png | src/assets/images/advisors/advisor-education-male.webp |
| advisor-communication-male.webp | generated | src/assets/images/raw/advisor-communication-male.png | src/assets/images/advisors/advisor-communication-male.webp |
| advisor-security-male.webp | generated | src/assets/images/raw/advisor-security-male.png | src/assets/images/advisors/advisor-security-male.webp |
| advisor-social-male.webp | generated | src/assets/images/raw/advisor-social-male.png | src/assets/images/advisors/advisor-social-male.webp |
| character-female-executive-1.webp | generated | src/assets/images/raw/character-female-executive-1.png | src/assets/images/characters/character-female-executive-1.webp |
| character-female-executive-2.webp | generated | src/assets/images/raw/character-female-executive-2.png | src/assets/images/characters/character-female-executive-2.webp |
| character-senior-leader.webp | generated | src/assets/images/raw/character-senior-leader.png | src/assets/images/characters/character-senior-leader.webp |
| character-indigenous-leader.webp | generated | src/assets/images/raw/character-indigenous-leader.png | src/assets/images/characters/character-indigenous-leader.webp |
| character-youth-activist.webp | fallback-crop | src/assets/images/raw/character-youth-activist.png | src/assets/images/characters/character-youth-activist.webp |
| character-business-executive.webp | fallback-crop | src/assets/images/raw/character-business-executive.png | src/assets/images/characters/character-business-executive.webp |
| advisor-health-female.webp | fallback-crop | src/assets/images/raw/advisor-health-female.png | src/assets/images/advisors/advisor-health-female.webp |
| advisor-justice-male.webp | fallback-crop | src/assets/images/raw/advisor-justice-male.png | src/assets/images/advisors/advisor-justice-male.webp |